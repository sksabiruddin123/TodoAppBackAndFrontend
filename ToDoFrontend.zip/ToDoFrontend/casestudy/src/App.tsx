import { BrowserRouter, Route, Switch } from "react-router-dom";
import ListOfTodo from "./ListOfTodo";
import 'bootstrap/dist/css/bootstrap.min.css';



function App(){
    return(<>
   
   <BrowserRouter>
   <Switch>
    <Route exact path="/" component={ListOfTodo} ></Route>
   </Switch>
   </BrowserRouter>

    </>)
}


export default App;