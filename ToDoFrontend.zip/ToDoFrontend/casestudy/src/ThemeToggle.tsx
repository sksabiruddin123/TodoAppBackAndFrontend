import { useEffect, useState } from "react";
import { Button } from "react-bootstrap";
import { Sun, Moon } from 'react-bootstrap-icons';

const ThemeToggle: React.FC = () => {
    const [isDarkMode, setIsDarkMode] = useState(false);

    useEffect(() => {
        const savedTheme = localStorage.getItem('theme');
        if (savedTheme === 'dark') {
            setIsDarkMode(true);
            document.body.setAttribute('data-bs-theme', 'dark');
        }
    }, []);

    const toggleTheme = () => {
        if(isDarkMode) {
            document.body.removeAttribute('data-bs-theme')
            localStorage.setItem('theme','light');
        }
        else{
            document.body.setAttribute('data-bs-theme', 'dark');
            localStorage.setItem('theme','light');
        }
        setIsDarkMode(!isDarkMode);
    };

    return (
       <Button onClick={toggleTheme} 
                variant={isDarkMode ? "light" : "dark"}
                className="position-fixed top-0 end m-3">

             { isDarkMode ? <Sun size={20}/> : <Moon size={20} />  }       

       </Button>
    );

}

export default ThemeToggle;