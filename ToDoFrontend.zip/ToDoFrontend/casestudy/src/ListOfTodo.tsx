import { useEffect, useState } from "react";
import { completeTodo, createTodo, deleteTodo, incompleteTodo, listTodos, updateTodo } from "./services/Todo";
import { Button, Container, Form, Table } from "react-bootstrap";
import ThemeToggle from "./ThemeToggle";


type todo={
    id:number;
    title:string,
    description:string,
    completed:boolean
}

const ListOfTodo =() => {
 
    const[todos,setTodos] = useState<todo[]>([]);
    const[editingTodo, setEditingTodo] = useState<todo | null>(null);
    const[newTodo, setNewTodo] = useState<Omit<todo, 'id' | 'completed' >>({ title: '', description: '' });
    const[isAddingNew, setIsAddingNew] =useState(false);

    useEffect(()=>{
        getTodos();
    },
    []);

    function getTodos(){
        listTodos().then((response) => {
            console.log(response.data)
            setTodos(response.data)
        }).catch((error) => console.log(error))
    }

    function handleCreateTodo(){

        createTodo({ ...newTodo , completed: false})
        .then(() => {
            getTodos();
            setNewTodo({ title: '' ,description: ''});
            setIsAddingNew(false);
        }).catch((error) => console.log(error));

    }

    function handleUpdateTodo(){
        if (editingTodo) {
            updateTodo(editingTodo.id, editingTodo).then(() => {
                getTodos();
                setEditingTodo(null);
            }).catch((error) => console.log(error));
        }
    }

    function deleteTask(id: number) {
        deleteTodo(id).then((response) => {
            console.log(response.data)
            getTodos()
        }).catch((error) => console.log(error))
    }


    function handleComplete(id: number) {
        completeTodo(id).then(() => {
            getTodos();
        }).catch((error) => console.log(error));
    }

    function handleIncomplete(id: number) {
        incompleteTodo(id).then(() => {
            getTodos();
        }).catch((error) => console.log(error));
    }
    

    return(<>
 
     

      <Container className="mt-5">
      <ThemeToggle />
   
      <header >
      <h1 className="text-center mb-4">Todo Management Application</h1>
      </header>    
      
   <Table striped bordered hover>

    <thead>
        <tr>
            <th>ID</th>
            <th>Title</th>
            <th>Description</th>
            <th>Completed</th>
            <th>Actions</th>
        </tr>
    </thead>

        <tbody>
 {
    todos.map((todo) => (

         <tr key={todo.id}>
            <td>{todo.id}</td>
            <td>
                {editingTodo?.id === todo.id ? (
                    <Form.Control
                         type="text"
                         value={editingTodo.title}
                         onChange={(e) => setEditingTodo({...editingTodo, title: e.target.value })}/>) : (todo.title)}
            </td>
             <td>
                {editingTodo?.id === todo.id ? (
                    <Form.Control
                        type="text"
                        value={editingTodo.description}
                        onChange={(e) => setEditingTodo({...editingTodo, description: e.target.value })}/>) : (todo.description)}
                            </td>
            <td>
                  {todo.completed ? "Yes" : "No"}
            </td>
            <td>
               {editingTodo?.id === todo.id ? ( <>
                  <Button variant="success" 
                      onClick={handleUpdateTodo}>
                                        Save
                 </Button>
                 <Button variant="secondary" 
                         className="ms-2" 
                         onClick={() => setEditingTodo(null)}>
                                            Cancel
                </Button>
                 </>) : (
                 <Button variant="warning" 
                         onClick={() => setEditingTodo(todo)}>
                                        Update
                 </Button>)}
                 <Button variant="danger" 
                         className="ms-2" 
                         onClick={() => deleteTask(todo.id)}>
                                    Delete
                 </Button>

                 {!todo.completed && (
                        <Button variant="success" 
                                className="ms-2" 
                                onClick={() => handleComplete(todo.id)}>
                                        Complete
                                    </Button>
                                )}
                 {todo.completed && (
                        <Button variant="secondary" 
                                className="ms-2" 
                                onClick={() => handleIncomplete(todo.id)}>
                                        Incomplete
                                    </Button>
                                )}

                            </td>
                        </tr>
                    ))}

    {
        isAddingNew && (
            <tr>
                 <td>-</td>
                <td>
                    <Form.Control type="text"
                                  placeholder="Enter Title" 
                                  value={newTodo.title}
                                  onChange={(e) =>setNewTodo( { ...newTodo, title: e.target.value})}/>
                </td>
                <td>
                    <Form.Control type="text"
                                  placeholder="Enter Description" 
                                  value={newTodo.description}
                                  onChange={(e) =>setNewTodo( { ...newTodo, description: e.target.value})}/>
                </td>
                <td>
                <td>No</td>
                </td>
                <td>
                <Button variant="success" onClick={handleCreateTodo}>
                                    Save
                </Button>
                <Button variant="secondary" className="ms-2" onClick={() => setIsAddingNew(false)}>
                                    Cancel
                </Button>
                </td>
            </tr>
        )}
                </tbody>
            </Table>
      


      { !isAddingNew && (
        <Button variant="primary" onClick={() => setIsAddingNew(true)}>
            Add New Todo
        </Button>
      )}
    
    </Container>

    </>)
}

export default ListOfTodo;